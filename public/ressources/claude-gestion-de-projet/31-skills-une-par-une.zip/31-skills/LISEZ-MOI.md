# Gestion de projet : 31 skills pour Claude

Une skill est une méthode écrite une fois, que Claude applique à chaque fois. Cette bibliothèque en réunit 31, en français, pour mener un projet du cadrage à la clôture. Claude prépare les documents, vous gardez les décisions.

## Ce qu'elle contient

- **Cadrer** : fiche-de-cadrage, perimetre-projet, objectifs-projet, parties-prenantes, budget-previsionnel
- **Planifier** : decoupage-en-taches, jalons-projet, retroplanning, dependances-projet, plan-de-charge
- **Animer les réunions** : ordre-du-jour, reunion-de-lancement, point-equipe, comite-de-pilotage, reunion-de-decision
- **Suivre** : tableau-de-bord, point-avancement, suivi-du-budget, liste-des-actions, suivi-des-ecarts
- **Anticiper les risques** : registre-des-risques, pre-mortem, demande-de-changement, escalade-blocage
- **Rendre compte** : compte-rendu-reunion, journal-des-decisions, compte-rendu-client, note-direction
- **Clôturer** : recette-et-validation, bilan-de-projet, retour-experience

## Installer

- **Offre Claude payante, en une fois :** dans Claude, ouvrez Plug-ins, puis Ajouter, puis Importer un plug-in, et choisissez `gestion-projet-noesisai.plugin` (ou le `.zip`, sans le décompresser).
- **Skill par skill :** Plug-ins, Ajouter, Importer un Skill, puis le fichier `.skill` voulu. L'exécution de code et la création de fichiers doivent être activées dans Paramètres, Capacités.

## Utiliser

Décrivez votre besoin avec vos mots : Claude choisit la skill. Ou tapez `/` et choisissez-la dans la liste.

## Données et fonctionnement

Les skills sont des fichiers texte. Cinq d'entre elles (retroplanning, dependances-projet, plan-de-charge, suivi-du-budget, suivi-des-ecarts) contiennent un petit calculateur en Python, sans installation, qui lit vos données et affiche un tableau. Rien n'est envoyé ailleurs : aucun fichier ne contacte un service extérieur.

Mode d'emploi complet : https://noesisai.fr/ressources/claude-gestion-de-projet
